// PPL 2023 HW4 Part2

// Q 2.1 

// Specify the return type.
export const delayedSum = async (a: number, b: number, delay: number) => {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
          const sum : number = a + b;
          resolve(sum);
        }, delay);
      });
}


export const testDelayedSum = () => {
    const delay : number = 2000; // Specify the delay in milliseconds

    const startTime : number = Date.now();
    delayedSum(2, 3, delay)
      .then((sum) => {
        const endTime : number = Date.now();
        const actualDelay : number = endTime - startTime;
        console.log('Expected Delay:', delay);
        console.log('Actual Delay:', actualDelay);
        console.log('Sum:', sum);
      })
      .catch((error) => {
        console.error('Error:', error);
      });
 }
 

// Q 2.2

// Values returned by API calls.
export type Post = {
    userId: number;
    id: number;
    title: string;
    body: string;
}

// When invoking fetchData(postsUrl) you obtain an Array Post[]
// To obtain an array of posts
export const postsUrl = 'https://jsonplaceholder.typicode.com/posts'; 

// Append the desired post id.
export const postUrl = 'https://jsonplaceholder.typicode.com/posts/'; 

// When invoking fetchData(invalidUrl) you obtain an error
export const invalidUrl = 'https://jsonplaceholder.typicode.com/invalid';

// Depending on the url - fetchData can return either an array of Post[] or a single Post.
// Specify the return type without using any.
export const fetchData = async (url: string): Promise<any> => {
    try {
      const response: Response = await fetch(url);
      
      if (!response.ok) {
        throw new Error(`HTTP error! Status: ${response.status}`);
      }
  
      const data = await response.json();
      return data;
    } catch (error : any) {
      throw new Error(`Fetch error: ${error.message}`);
    }
  };

export const testFetchData = async () => {
    try {
      const posts = await fetchData(postsUrl);
      console.log('Posts:', posts);
  
      const postId = 1;
      const post = await fetchData(postUrl + postId);
      console.log('Post:', post);
  
      const invalidData = await fetchData(invalidUrl);
      console.log('Invalid data:', invalidData);
    } catch (error) {
      console.error('Error:', error);
    }
  };

// Q 2.3

// Specify the return type.

// import fetch from 'node-fetch';

// export const fetchMultipleUrls = async (urls: string[]): Promise<any[]> => {
//   try {
//     const promises = urls.map(url => fetch(url).then(response => response.json()));
//     const results = await Promise.all(promises);
//     return results;
//   } catch (error) {
//     throw new Error(`Fetch error: ${error.message}`);
//   }
// };

// export const testFetchMultipleUrls = async () => {
//   try {
//     const apiUrl1 = 'https://jsonplaceholder.typicode.com/posts/1';
//     const apiUrl2 = 'https://jsonplaceholder.typicode.com/posts/2';
//     const apiUrl3 = 'https://jsonplaceholder.typicode.com/posts/3';
//     const urls = [apiUrl1, apiUrl2, apiUrl3];

//     const data = await fetchMultipleUrls(urls);
//     console.log('Fetched data:', data);
//   } catch (error) {
//     console.error('Error:', error);
//   }
// };

export const fetchMultipleUrls = async (urls: string[]): Promise<any[]> => {
    try {
      const fetchPromises = urls.map((url) => fetch(url));
      const responses = await Promise.all(fetchPromises);
  
      if (responses.every((response) => response.ok)) {
        const dataPromises = responses.map((response) => response.json());
        return Promise.all(dataPromises);
      } else {
        throw new Error('At least one request failed');
      }
    } catch (error : any) {
      throw new Error(`Request failed: ${error.message}`);
    }
  };
  
  export const testFetchMultipleUrls = async () => {
    try {
        const apiUrlBase = 'https://jsonplaceholder.typicode.com/posts/';
        const postsCount = 20;
        const urls = [];
        
        for (let i = 1; i <= postsCount; i++) {
          const apiUrl = apiUrlBase + i;
          urls.push(apiUrl);
        }
    
        const responseData = await fetchMultipleUrls(urls);
        console.log('Fetched data:', responseData);
      } catch (error) {
        console.error('Error:', error);
      }
    };
    
    
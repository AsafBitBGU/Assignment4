import { describe, expect, test } from '@jest/globals'
import {
    delayedSum, Post, postsUrl, postUrl, invalidUrl, fetchData, fetchMultipleUrls
} from '../src/part2';

describe('Assignment 4 Part 2', () => {
    describe('Q2.1 delayedSum (6 points)', () => {
        test('delayedSum returns the sum', () => {
            const a = 2;
            const b = 3;
            const delay = 2000;

            return delayedSum(a, b, delay)
                .then((sum) => {
                expect(sum).toBe(a + b);
                });
            })
        
        test('delayedSum waits at least the specified delay', () => {
            const a = 2;
            const b = 3;
            const delay = 2000;

            const startTime = Date.now();

            return delayedSum(a, b, delay)
                .then(() => {
                const endTime = Date.now();
                const actualDelay = endTime - startTime;

                expect(actualDelay).toBeGreaterThanOrEqual(delay);
            });
        })
    })

    describe('Q2.2 fetchData (12 points)', () => {
        test('successful call to fetchData with array result', async () => {
            try {
                const posts = await fetchData(postsUrl);
                expect(Array.isArray(posts)).toBe(true);
                expect(posts.length).toBeGreaterThan(0);
              } catch (error) {
                // Test failed if an error occurred
                expect(error).toBeNull();
              }
        })

        test('successful call to fetchData with Post result', async () => {
            try {
                const postId = 1;
                const post = await fetchData(postUrl + postId);
                expect(typeof post).toBe('object');
                expect(post).toHaveProperty('userId');
                expect(post).toHaveProperty('id');
                expect(post).toHaveProperty('title');
                expect(post).toHaveProperty('body');
              } catch (error) {
                // Test failed if an error occurred
                expect(error).toBeNull();
              }
        })

        test('failed call to fechData', async () => {
            try {
                await fetchData(invalidUrl);
                // Test failed if the above line didn't throw an error
                expect(true).toBe(false);
              } catch (error) {
                // Test passed if an error occurred
                expect(error).toBeDefined();
              }
        })

    })

    describe('Q2.3 fetchMultipleUrls (12 points)', () => {
        test('successful call to fetchMultipleUrls', async () => {
            try {
                const apiUrlBase = 'https://jsonplaceholder.typicode.com/posts/';
                const postsCount = 5;
                const urls = [];
          
                for (let i = 1; i <= postsCount; i++) {
                  const apiUrl = apiUrlBase + i;
                  urls.push(apiUrl);
                }
          
                const responseData = await fetchMultipleUrls(urls);
                expect(responseData.length).toBe(postsCount);
              } catch (error : any) {
                fail('Unexpected error occurred: ' + error.message);
              }
            })
        

        test('successful call to fetchMultipleUrls: verify results are in the expected order ', async () => {
            try {
                const apiUrlBase = 'https://jsonplaceholder.typicode.com/posts/';
                const postsCount = 5;
                const urls = [];
          
                for (let i = 1; i <= postsCount; i++) {
                  const apiUrl = apiUrlBase + i;
                  urls.push(apiUrl);
                }
          
                const responseData = await fetchMultipleUrls(urls);
          
                for (let i = 0; i < responseData.length; i++) {
                  const expectedId = i + 1;
                  const post = responseData[i];
          
                  expect(post.id).toBe(expectedId);
                }
              } catch (error : any) {
                fail('Unexpected error occurred: ' + error.message);
              }
        })

        test('failed call to fetchMultipleUrls', async () => {
            try {
                const invalidUrl = 'https://jsonplaceholder.typicode.com/invalid';
                const urls = [invalidUrl];
          
                await fetchMultipleUrls(urls);
                fail('Expected fetchMultipleUrls to throw an error, but it succeeded');
              } catch (error : any) {
                expect(error.message).toContain('Request failed');
              }
        })
    })
});